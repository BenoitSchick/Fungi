.obj/src/main.o: src/main.c /usr/include/stdc-predef.h \
 /usr/include/stdio.h /usr/include/features.h \
 /usr/include/arm-linux-gnueabihf/sys/cdefs.h \
 /usr/include/arm-linux-gnueabihf/bits/wordsize.h \
 /usr/include/arm-linux-gnueabihf/gnu/stubs.h \
 /usr/include/arm-linux-gnueabihf/gnu/stubs-hard.h \
 /usr/lib/gcc/arm-linux-gnueabihf/6/include/stddef.h \
 /usr/include/arm-linux-gnueabihf/bits/types.h \
 /usr/include/arm-linux-gnueabihf/bits/typesizes.h /usr/include/libio.h \
 /usr/include/_G_config.h /usr/include/wchar.h \
 /usr/lib/gcc/arm-linux-gnueabihf/6/include/stdarg.h \
 /usr/include/arm-linux-gnueabihf/bits/stdio_lim.h \
 /usr/include/arm-linux-gnueabihf/bits/sys_errlist.h \
 /usr/include/arm-linux-gnueabihf/bits/stdio.h /usr/include/unistd.h \
 /usr/include/arm-linux-gnueabihf/bits/posix_opt.h \
 /usr/include/arm-linux-gnueabihf/bits/environments.h \
 /usr/include/arm-linux-gnueabihf/bits/confname.h /usr/include/getopt.h \
 /usr/include/time.h /usr/include/arm-linux-gnueabihf/bits/time.h \
 /usr/include/xlocale.h /usr/include/arm-linux-gnueabihf/sys/socket.h \
 /usr/include/arm-linux-gnueabihf/sys/uio.h \
 /usr/include/arm-linux-gnueabihf/sys/types.h /usr/include/endian.h \
 /usr/include/arm-linux-gnueabihf/bits/endian.h \
 /usr/include/arm-linux-gnueabihf/bits/byteswap.h \
 /usr/include/arm-linux-gnueabihf/bits/byteswap-16.h \
 /usr/include/arm-linux-gnueabihf/sys/select.h \
 /usr/include/arm-linux-gnueabihf/bits/select.h \
 /usr/include/arm-linux-gnueabihf/bits/sigset.h \
 /usr/include/arm-linux-gnueabihf/sys/sysmacros.h \
 /usr/include/arm-linux-gnueabihf/bits/pthreadtypes.h \
 /usr/include/arm-linux-gnueabihf/bits/uio.h \
 /usr/include/arm-linux-gnueabihf/bits/socket.h \
 /usr/include/arm-linux-gnueabihf/bits/socket_type.h \
 /usr/include/arm-linux-gnueabihf/bits/sockaddr.h \
 /usr/include/arm-linux-gnueabihf/asm/socket.h \
 /usr/include/asm-generic/socket.h \
 /usr/include/arm-linux-gnueabihf/asm/sockios.h \
 /usr/include/asm-generic/sockios.h \
 /usr/include/arm-linux-gnueabihf/sys/stat.h \
 /usr/include/arm-linux-gnueabihf/bits/stat.h /usr/include/dirent.h \
 /usr/include/arm-linux-gnueabihf/bits/dirent.h \
 /usr/include/arm-linux-gnueabihf/bits/posix1_lim.h \
 /usr/include/arm-linux-gnueabihf/bits/local_lim.h \
 /usr/include/linux/limits.h /usr/include/stdlib.h \
 /usr/include/arm-linux-gnueabihf/bits/waitflags.h \
 /usr/include/arm-linux-gnueabihf/bits/waitstatus.h /usr/include/alloca.h \
 /usr/include/arm-linux-gnueabihf/bits/stdlib-bsearch.h \
 /usr/include/arm-linux-gnueabihf/bits/stdlib-float.h \
 /usr/include/netinet/in.h \
 /usr/lib/gcc/arm-linux-gnueabihf/6/include/stdint.h \
 /usr/include/stdint.h /usr/include/arm-linux-gnueabihf/bits/wchar.h \
 /usr/include/arm-linux-gnueabihf/bits/in.h /usr/include/string.h \
 /usr/include/arm-linux-gnueabihf/bits/string.h \
 /usr/include/arm-linux-gnueabihf/bits/string2.h \
 /usr/local/include/bcm2835.h src/../include/ad7770.h
